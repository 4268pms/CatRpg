package CatRPG;

import java.util.Scanner;

public class Food {

	public void run(Cat x) {
		loop: while (true) {
			System.out.println("1.츄르 , 2.참치캔 , 3.캣 프로틴 , 4.뒤로 , 5.상태창");
			Scanner sc = new Scanner(System.in) ;
				String c = sc.next();
				switch (c) {
				case "1":
					System.out.println("----------"+x.name + "(이)가 츄르를 좋아합니다.----------");
					x.getExp(10);	//경험치 10 증가
					x.getSatiety(20);
					break;
				case "2":
					System.out.println("----------"+x.name + "(이)가 참치캔을 좋아합니다.--------------");
					x.getExp(5);
					x.getSatiety(20);
					break;
				case "3":
					System.out.println("----------"+x.name + "(이)가 캣 프로틴을 좋아합니다.----------");
					x.getExp(10);
					x.getSatiety(10);
					break;
				case "4":
					break loop;
				case "5":
					x.showInfo();
					break;
				default:
					System.out.println(x.name + ":냥?.");
					break loop;
				}
			}
		}
	}

