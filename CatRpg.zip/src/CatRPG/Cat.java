package CatRPG;

public class Cat {
	String name; // 이름
	int maxsatiety; // 최대포만감
	int satiety; // 포만감
	int level; // 레벨
	int exp; // 경험치

	public Cat() {
	}

	public Cat(String name, int satiety, int level, int exp) {
		this.name = name;
		this.satiety = satiety;
		this.maxsatiety = 200;
		this.level = 1;
		this.exp = 0;
	}

	//	경험치를 얻는 메소드
	public void getExp(int exp) {
		System.out.println("----------"
							+exp + "의 경험치를 획득하였습니다."
							+"----------");
		this.exp += exp;
		if (100 <= this.exp) {
			levelUp();
			this.exp -= 100;
		}
	}

	//	포만감을 얻는 메소드
	public void getSatiety(int satiety) {
		System.out.println("----------"+
							satiety + "의 포만감이 찼습니다."
									+ "----------");
		this.satiety += satiety;
		if (200 <= this.satiety) {// 포만감이 다 찼으면 포만감 안차게 하기
			System.out.println("------------포만감이 가득 찼습니다.------------");
			System.out.println("배부르다냥!");
			this.satiety = this.maxsatiety;
		}

	}
	// 포만감을 낮추는 메소드
	public void minusSatiety(int satiety) {
		System.out.println("----------"+satiety + "의 포만감이 줄었습니다.----------");
		this.satiety -= satiety;
		if(0 >= this.satiety) {
			System.out.println("배고프다냥!");
			this.satiety = 0;
		}
	}


	// 레벨업
	void levelUp() {
		level++;
		System.out.println("-------------LEVEL UP!!-------------");
	}
	public void gotoSleep() {
		try {
			for (int i = 0; i < 10; i++) {
				Thread.sleep(100);
				System.out.println("*");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// 상태창
	void showInfo() {
		System.out.println("================================");
		System.out.println("------------- 상태 ---------------");
		System.out.println("이름 : " + name);
		System.out.println("레벨 : " + level + "(" + exp + "/100)");
		System.out.println("포만감 : " + satiety + "/" + maxsatiety);
		System.out.println("================================");
		
	}
}
