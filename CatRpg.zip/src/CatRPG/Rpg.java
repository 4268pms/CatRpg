package CatRPG;

import java.util.Scanner;

public class Rpg {
	
	Food food = new Food();
	Play play = new Play();
	public void run(Cat x) {
		
		loop: while (true) {
			System.out.println("1.간식 주기 , 2.놀아 주기 , 3.잠자기 , 4.뒤로 , 5.상태창");
			Scanner sc = new Scanner(System.in);
			String c = sc.next();
			switch (c) {
			case "1":
				System.out.println("-------"+x.name + "(이)가 무슨 간식을 좋아할까요?-------");
				food.run(x);
				break;
			case "2":
				System.out.println("----------"+x.name + "(이)가 집사를 쳐다봤다냥!!----------");
				play.run(x);
				break;
			case "3":
				System.out.println("----------"+x.name + "(이)가 자려고 한다냥!!----------");
				x.gotoSleep();
				System.out.println("----------"+x.name + "(이)가 잠에서 일어났다냥!!----------");
				x.getExp(20);
				x.minusSatiety(50);
				break;
			case "4":
				break loop;
			case "5":
				x.showInfo();
				break;
			default:
				System.out.println(x.name + ":냥?.");
				break;
			}
		}
	}
}