package CatRPG;

import java.util.Scanner;

public class Play {

	public void run(Cat x) {
		loop:while (true) {
			System.out.println("1.캣 낚시대 , 2.쓰다듬기 , 3.구루밍 , 4.뒤로 , 5,상태창");
			Scanner sc = new Scanner(System.in);
			String c = sc.next();
			switch (c) {
			case "1":
				System.out.println("----------"+ x.name +"(이)가 뛰어 오른다냥!.----------");
				x.minusSatiety(20);
				break;
			case "2":
				System.out.println("----------"+ x.name +"(이)가 묘한 표정을 짓는다냥!.----------");
				x.minusSatiety(10);
				break;
			case "3":
				System.out.println("----------"+ x.name +":그르릉...그르릉...그르릉.----------");
				x.minusSatiety(15);
				break;
			case "4":
				break loop;
			case "5":
				x.showInfo();
				break;
			default:
				System.out.println(x.name + ":냥?.");
				break;
			}
		}
	}
}
