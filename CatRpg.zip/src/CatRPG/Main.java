package CatRPG;

import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		Rpg rpg = new Rpg();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("-------------고양이의 이름을 지어주세요-------------");
		String inputName = sc.next();
		System.out.println("제 이름은 이제 " + inputName + "입니다!");
		Cat kitty = new Cat(inputName, 0, 1, 200);	// 키티 객체 생성
		loop: while (true) {
			
			System.out.println("1.키우기 2.이름 수정 3.상태창");
			String cmd = sc.next();
			switch (cmd) {
			case "1":	// 이름 저장
				kitty.showInfo();
				rpg.run(kitty);
				break;
			case "2":	// 이름 수정
				System.out.println("지금 이름은 " + inputName + "입니다!");
				System.out.println("어떤 이름으로 수정하겠습니까?");
				String name1 = sc.next();
				kitty.name = name1;
				break;
			case "3":
				kitty.showInfo();
				break;
			default:
				System.out.println("냥?");
				break;
			}
		}
	}
}